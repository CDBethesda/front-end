// run "npm test" or "npm start" for development
// --------------------or-----------------------
// simply run "npm run build" for production

const APP = {
  API_URL: "http://cdbethesda.space"
};

export default APP;
